import "./App.css";
import React, { Component } from "react";
import Congratulations from "./Congratulations";
import "bootstrap/dist/css/bootstrap.min.css";
class SearchForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchTerm: "",
      points: "",
      wrongInput: false,
      wrongcharacter: true,
      wrongcharacter2: true,
      SubmitPressed: false,

      len: 0,
      word: ""
    };

    this.onSearchFormChange = this.onSearchFormChange.bind(this);
    this.onSubmitButtonPress = this.onSubmitButtonPress.bind(this);
  }
  onSearchFormChange(event) {
    var retest = /^[a-zA-Z]+$/;

    if (event.target.value === "" || retest.test(event.target.value)) {
      this.setState({ searchTerm: event.target.value });
      this.setState({ wrongcharacter: true });
    } else {
      this.setState({ wrongcharacter: false });
    }
  }

  onSubmitButtonPress() {
    var answer = this.props.bestAnswer.toUpperCase();
    var userInput = this.state.searchTerm.toUpperCase();
    var count = 0;
    var character = "";
    console.log(userInput.length);
    for (var j = 0; j < answer.length; j++) {
      for (var i = 0; i < userInput.length; i++) {
        if (userInput.charAt(i) === answer.charAt(j)) {
          character = answer.charAt(j);
          answer = answer.replace(character, "");
          count = count + 1;
        } else {
          this.setState({ wrongcharacter2: false });
        }
      }
    }

    if (count === userInput.length) {
      this.setState({ wrongInput: true });
    } else {
      this.setState({ wrongInput: false });
    }

    this.props.submitPressed();
    this.setState({
      SubmitPressed: true,
      word: this.state.searchTerm,
      len: this.state.searchTerm.length
    });
  }
  render() {
    let wronganswer = this.state.wrongcharacter;

    return (
      <div className="AnswerForm">
        {this.state.SubmitPressed === true || this.props.isFinished ? (
          <Congratulations
            word={this.state.word}
            wordlength={this.state.len}
            submitbutton={this.state.SubmitPressed}
            bestAnswer={this.props.bestAnswer.toUpperCase()}
            wrongInput={this.state.wrongInput}
            wrongcharacters={this.state.wrongcharacter}
            isFinished={this.props.isFinished}
          />
        ) : (
          <div>
            {!this.props.isFinished && (
              <div>
                <p>Type in your answer here:</p>
                <input
                  type="text"
                  className="form-control"
                  maxLength={9}
                  value={this.state.searchTerm}
                  onChange={this.onSearchFormChange}
                  required
                />

                {wronganswer === false ? (
                  <p>You have entered an invalid character</p>
                ) : null}
                <button
                  type="button"
                  className="btn btn-primary btn-lg submit"
                  onClick={this.onSubmitButtonPress}
                >
                  Submit
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }
}
export default SearchForm;
