import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Definition from "./Definition";

class Congratulations extends Component {
  constructor(props) {
    super(props);
    this.state = {
      word: "",
      submit: false,
      definitionFound: false,
      apiData: [],
      definition: []
    };
    this.onSubmitPressed = this.onSubmitPressed.bind(this);
  }

  async componentDidMount() {
    try {
      const word = this.props.word;
      const URL = "https://api.dictionaryapi.dev/api/v2/entries/en/" + word;
      const response = await fetch(URL);
      const data = await response.json();
      this.setState({ apiData: data });
      this.setState({
        definition: data[0].meanings[0].definitions[0].definition
      });
      this.setState({ definitionFound: true });
    } catch {
      this.setState({ definitionFound: false });
    }
  }

  onSubmitPressed() {
    this.setState({ submit: true });
  }
  render() {
    var word = this.props.word;
    const bestAnswer = this.props.bestAnswer;
    var wordlength = this.props.wordlength;
    var condition1 = this.props.wrongInput;
    var condition2 = this.state.definitionFound;
    var condition3 = !this.state.definitionFound;
    var condition4 = !this.state.submit;
    var condition5 = this.props.wrongcharacters;

    return (
      <div className="Congratulations">
        {this.props.isFinished && (
          <div>
            <h1>TIMES UP!</h1>
            <br />
            <h2>You Got:</h2>
            <h3>0 Points</h3>
            <br />
            <h5>
              The best answer was: <br />
              {this.props.bestAnswer.toUpperCase()}
            </h5>
          </div>
        )}

        {condition4 && condition1 && (
          <div className="Congratspage">
            {condition2 && (
              <div>
                <h1>CONGRATULATIONS</h1>
                <br />
                <h2>You Got:</h2>
                <h3>{wordlength} Points</h3>
                <br />
                <h2>You Typed: {word.toUpperCase()}</h2>
                <br />
                <h6>
                  Definition: <Definition word={word} />
                </h6>
                <br />
                <h6>
                  The best answer was: <br />
                  {bestAnswer}
                </h6>
              </div>
            )}
          </div>
        )}

        {condition4 && !this.props.isFinished && (
          <div>
            {condition3 && (
              <div className="Congratspage">
                <h1>SORRY YOUR ANSWER IS INCORRECT</h1>
                <h2>You Got:</h2>
                <h3>0 Points</h3>
                <br />
                {condition5 && wordlength !== 0 && (
                  <div>
                    <h2>
                      {word.toUpperCase()} not made up of the given characters
                    </h2>
                  </div>
                )}
                {!condition5 && (
                  <div>
                    <h2>{word.toUpperCase()} not a word</h2>
                  </div>
                )}
                {wordlength === 0 && (
                  <div>
                    <h2>You have not entered any characters</h2>
                  </div>
                )}
                <br />

                <h2>The best answer was: </h2>
                <br />
                <h3>{bestAnswer}</h3>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }
}

export default Congratulations;
