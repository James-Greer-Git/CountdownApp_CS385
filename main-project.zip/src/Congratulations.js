import React, { Component } from "react";
import Definition from "./Definition";
import App from "./App";

class Congratulations extends Component {
  constructor(props) {
    super(props);
    this.state = {
      word: "",
      submit: false,
      definitionFound: false,
      apiData: [],
      definition: []
    };
    this.onSubmitPressed = this.onSubmitPressed.bind(this);
  }

  async componentDidMount() {
    try {
      const word = this.props.word;
      const URL = "https://api.dictionaryapi.dev/api/v2/entries/en/" + word;
      const response = await fetch(URL);
      const data = await response.json();
      this.setState({ apiData: data });
      this.setState({
        definition: data[0].meanings[0].definitions[0].definition
      });
      this.setState({ definitionFound: true });
    } catch {
      this.setState({ definitionFound: false });
    }
  }

  onSubmitPressed() {
    this.setState({ submit: true });
  }
  render() {
    var word = this.props.word;
    var wordlength = this.props.wordlength;

    return (
      <div className="Congratulations">
        {this.state.definitionFound ? (
          <>
            <>
              {" "}
              <h1>CONGRATULATIONS</h1>
              <p>You Got:</p>
              {wordlength} Pionts
              <p>You Typed:</p>
              {word}
              <p>Definition:</p>
            </>
            <Definition word={word} />
            <button onClick={this.onSubmitPressed}>PLAY AGAIN</button>
          </>
        ) : (
          <div>
            <h1>SORRY THIS IS NOT A WORD</h1>
            <button onClick={this.onSubmitPressed}>PLAY AGAIN</button>
          </div>
        )}
      </div>
    );
  }
}
export default Congratulations;
