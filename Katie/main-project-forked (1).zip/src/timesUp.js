import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

class timesUp extends Component {

  render(){
    return(
      <div className="Congratulations">
       
          <div className="Congratspage">
          
             
                <h1>TIMES UP!</h1>
                <br />
                <h2>You Got:</h2>
                <h3>0 Points</h3>
                <br />
                <h6>
                  The best answer was: <br />
                  
                </h6>
              
            </div>
         
      </div>

    )
  }
}
export default timesUp;