export const randomwords = [
  "labelling",
  "quadratic",
  "vaccinate",
  "yachtsman",
  "bleachers"
];
