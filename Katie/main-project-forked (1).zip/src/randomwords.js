export var randomwords = [
  "labelling",
  "quadratic",
  "vaccinate",
  "yachtsman",
  "bleachers"
];
