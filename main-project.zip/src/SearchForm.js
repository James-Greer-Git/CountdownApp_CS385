import React, { Component } from "react";
import Congratulations from "./Congratulations";
class SearchForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchTerm: "",
      pionts: "",
      wrongInput: true,
      SubmitPressed: false,
      len: 0,
      word: ""
    };

    this.onSearchFormChange = this.onSearchFormChange.bind(this);
    this.onSubmitButtonPress = this.onSubmitButtonPress.bind(this);
  }
  onSearchFormChange(event) {
    var retest = /^[a-zA-Z]+$/;

    if (event.target.value === "" || retest.test(event.target.value)) {
      this.setState({ searchTerm: event.target.value });
      this.setState({ wrongInput: true });
    } else {
      this.setState({ wrongInput: false });
    }
  }

  onSubmitButtonPress() {
    this.setState({
      SubmitPressed: true,
      word: this.state.searchTerm,
      len: this.state.searchTerm.length
    });
    //call function in game and set showHeadings to false
  }
  render() {
    let wronganswer = this.state.wrongInput;

    return (
      <div className="AnswerForm">
        <p>Type in your answer here:</p>
        <form>
          <input
            maxLength={9}
            value={this.state.searchTerm}
            onChange={this.onSearchFormChange}
          />
        </form>
        {wronganswer === false ? (
          <p>You have entered an invalid character</p>
        ) : null}
        <button onClick={this.onSubmitButtonPress}>Submit</button>
        {this.state.SubmitPressed === true ? (
          <Congratulations
            word={this.state.word}
            wordlength={this.state.len}
            submitbutton={this.state.SubmitPressed}
          />
        ) : null}
      </div>
    );
  }
}
export default SearchForm;
