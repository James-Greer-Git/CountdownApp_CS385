import React, { Component } from "react";
import GenerateRandomLetters from "./GenerateRandomLetters";
import SearchForm from "./SearchForm.js";
import App from "./App.js";
import Timer2 from "./Timer2.js";

class Game extends Component {
  constructor(props) {
    super(props);
    this.state = {
      SubmitPressed: false,
      HomepagePressed: false,
      word: "",
      PlayPressed: false,
      showHeadings: true
    };
    this.onPlayButtonPress = this.onPlayButtonPress.bind(this);
    this.onHomePagePressed = this.onHomePagePressed.bind(this);
  }
  onPlayButtonPress() {
    this.setState({ PlayPressed: true });
    console.log("Play Button Pressed");
  }

  onHomePagePressed() {
    this.setState({ HomepagePressed: true });
  }

  render() {
    var secondsfromprops = this.props.seconds;
    var choicefromprops = this.props.choice;

    return (
      <div className="App">
        {this.state.HomepagePressed === false ? (
          <div>
            {this.state.showHeadings && (
              <div>
                <h1>COUNTDOWN GAME</h1>
                <p>You have selected : {choicefromprops}</p>
                <button onClick={this.onHomePagePressed}>
                  Back To Homepage
                </button>
                <h1>PRESS PLAY TO BEGIN</h1>
                <button>PLAY!</button>
                <hr />
                <h3>Timer</h3>
                <Timer2 initialSeconds={secondsfromprops} />
                <h3>Letters</h3>
                <GenerateRandomLetters />
              </div>
            )}
            <div>
              <SearchForm showHeadings={this.showHeadings} />
            </div>
          </div>
        ) : (
          <div>
            {this.state.HomepagePressed === true ? (
              <div>
                <App />
              </div>
            ) : null}
          </div>
        )}
      </div>
    ); // end of return statement
  } // end of render function
}

export default Game;
